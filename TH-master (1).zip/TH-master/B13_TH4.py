ds=input("Nhap chuoi: ").split()
print(' vị trí chuỗi abc là: ',ds.index('abc'))