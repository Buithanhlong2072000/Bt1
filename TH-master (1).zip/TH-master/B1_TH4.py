s=input(" Nhap chuoi: ")
for ch in s:
    print(ch)

