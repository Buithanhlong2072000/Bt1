ds=input("Nhap chuoi: ").split()

