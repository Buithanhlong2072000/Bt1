a=" Hello World"
def say_hello():
    a="Hello"
    print(a)
say_hello(a)
print(a)

