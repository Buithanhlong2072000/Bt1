s=input(' Nhap chuoi: ').split()
print(' Tu co do dai dai  nhat la: ',max(s))