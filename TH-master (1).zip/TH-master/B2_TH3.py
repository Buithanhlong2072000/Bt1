def sum(a,b):
    return a+b
c=sum(4,5)
print("Tong cua 4 va 5 = "+ str(c))
