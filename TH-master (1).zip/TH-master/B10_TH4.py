ds=input("Nhap chuoi: ").split()
x=ds[1:-1]
for c in x:
    print(c)
print(ds)
