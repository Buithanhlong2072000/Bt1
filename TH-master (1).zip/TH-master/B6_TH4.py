name=input('Xin moi nhap ho va ten: ')
ho=name.split()[0]
print('Ho cua ban la:',ho)
ten=name.split()[1]
print('Ten cua ban la: ',ten)
