a="hi i am python programmer"
b=a.split()
print(b)
c="".join(b)
print(c)
