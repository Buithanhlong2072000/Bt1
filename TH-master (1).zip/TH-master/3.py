n=int(input("Enter a number--->"))
if n%2==0:
    print("EVEN Number");
else:
    print("ODD Number");
    
