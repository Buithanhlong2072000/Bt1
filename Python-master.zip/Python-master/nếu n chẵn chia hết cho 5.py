n=int(input('Nhap n:'))
if n%2==0 and n%5==0:
    print(' say hello ')
else:
    print('Ngu ngốc')