print(" Hello world ! ")
print(" Phan Xuan Hieu, MSV: 18575202160020, Nghanh: KTĐK & TĐH")
