values=input("Nhập vào các giá trị:")
l=values.split(",")
t=tuple(l)
print (l)
print(t)

