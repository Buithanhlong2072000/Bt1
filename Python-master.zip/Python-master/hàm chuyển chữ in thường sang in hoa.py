def chuyen_chu(n):
   print('Sau khi chuyển là :'+ n.upper())
chuyen_chu(" hello world ")

